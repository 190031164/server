# mailserver-web

This image contains

[roundcube](https://roundcube.net)
and [mailserver-admin](https://github.com/jeboehm/mailserver-admin).
